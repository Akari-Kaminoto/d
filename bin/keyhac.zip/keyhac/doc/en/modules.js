var modules =
[
    [ "Keymap feature", "group__keymap.html", "group__keymap" ],
    [ "Low-level OS feature(pyauto)", "group__pyauto.html", "group__pyauto" ],
    [ "Clipboard history list feature", "group__clipboardlist.html", "group__clipboardlist" ],
    [ "List window feature", "group__listwindow.html", "group__listwindow" ],
    [ "Thread support feature", "group__threadutil.html", "group__threadutil" ],
    [ "Sub-process execution feature", "group__subprocess.html", "group__subprocess" ],
    [ "Configuration script related", "group__userconfig.html", "group__userconfig" ],
    [ "INI file feature", "group__ini.html", "group__ini" ],
    [ "Miscellaneous features", "group__misc.html", "group__misc" ]
];