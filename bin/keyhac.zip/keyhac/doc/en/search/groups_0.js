var searchData=
[
  ['clipboard_20history_20list_20feature',['Clipboard history list feature',['../group__clipboardlist.html',1,'']]],
  ['configuration_20script_20related',['Configuration script related',['../group__userconfig.html',1,'']]]
];
