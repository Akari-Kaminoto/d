var classckit_1_1ckit__subprocess_1_1_sub_process =
[
    [ "__init__", "classckit_1_1ckit__subprocess_1_1_sub_process.html#ac775ee34451fdfa742b318538164070e", null ],
    [ "__call__", "classckit_1_1ckit__subprocess_1_1_sub_process.html#a66b2fc5e7e096cac91755849fbf6de76", null ],
    [ "cancel", "classckit_1_1ckit__subprocess_1_1_sub_process.html#a807ed97eee69cbd1e4b9077ac361d77c", null ]
];